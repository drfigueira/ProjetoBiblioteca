package br.edu.ifsp.dsis4.biblioteca.io;

public interface ComponenteIO {

    void setArquivo(String endereco);

}
