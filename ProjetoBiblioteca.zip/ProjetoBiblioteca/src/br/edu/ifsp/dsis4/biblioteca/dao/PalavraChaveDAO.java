package br.edu.ifsp.dsis4.biblioteca.dao;

import br.edu.ifsp.dsis4.biblioteca.entidades.PalavraChave;
import br.edu.ifsp.dsis4.biblioteca.bd.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PalavraChaveDAO implements CrudDAO<PalavraChave> {

    @Override
    public void salvar(PalavraChave object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualizar(PalavraChave object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remover(PalavraChave object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<PalavraChave> buscar(int min, int max) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<PalavraChave> buscarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<PalavraChave> buscarPalavrasChavePorObra(int id_obra) {
        String sql = "SELECT * FROM palavra_chave WHERE id_palavra_chave IN (SELECT id_palavra_chave FROM obra_palavra_chave WHERE id_obra = ?)";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection();
            PreparedStatement pStat = con.prepareStatement(sql)) 
        {
            pStat.setInt(1, id_obra);
            try(ResultSet rs = pStat.executeQuery()) {
                List<PalavraChave> palavras = new ArrayList<>();
                while(rs.next()) {
                    int id = rs.getInt("id_palavra_chave");
                    String nome = rs.getString("palavra");
                    PalavraChave palavra = new PalavraChave(id, nome);
                    palavras.add(palavra);
                }
                return palavras;
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
}
