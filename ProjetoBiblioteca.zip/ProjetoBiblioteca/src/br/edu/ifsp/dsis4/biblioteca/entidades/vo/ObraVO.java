package br.edu.ifsp.dsis4.biblioteca.entidades.vo;

public class ObraVO {
}
