package br.edu.ifsp.dsis4.biblioteca.dao;

import br.edu.ifsp.dsis4.biblioteca.entidades.Autor;
import br.edu.ifsp.dsis4.biblioteca.entidades.CategoriaLiteraria;
import br.edu.ifsp.dsis4.biblioteca.entidades.Exemplar;
import br.edu.ifsp.dsis4.biblioteca.entidades.Obra;
import br.edu.ifsp.dsis4.biblioteca.entidades.PalavraChave;
import br.edu.ifsp.dsis4.biblioteca.bd.ConexaoBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ObraDAO implements CrudDAO<Obra> {

    @Override
    public void salvar(Obra object) {
        String sql1 = "INSERT INTO obra_literaria (id_obra, isbn, titulo_obra, id_categoria_obra, data_publicacao, edicao, editora) " +
                "VALUES (obra_literaria.NEXTVAL, ?, ?, ?, ?, ?, ?)";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection()) {
            con.setAutoCommit(false);
            try(PreparedStatement pStat = con.prepareStatement(sql1)) {
                pStat.setString(1, object.getIsbn());
                pStat.setString(2, object.getTitulo());
                pStat.setInt(3, object.getCategoria().getId());
                pStat.setDate(4, java.sql.Date.valueOf(object.getDataPublicacao()));
                pStat.setInt(5, object.getNumEdicao());
                pStat.setString(6, object.getEditora());
                pStat.executeUpdate();
                salvarAutores(con, object);
                salvarPalavrasChave(con, object);
                salvarExemplares(con, object);
                con.commit();
            }
            catch (SQLException e) {
                con.rollback();
                throw new RuntimeException(e);
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    private void salvarPalavrasChave(Connection con, Obra obra) {
        String sql2 = "INSERT INTO palavra_chave (id_palavra_chave, palavra) " +
                "VALUES (palavra_chave_seq.NEXTVAL, ?)";
        if(!obra.getPalavrasChave().isEmpty()) {
            try(PreparedStatement pStat = con.prepareStatement(sql2)) {
                for(PalavraChave p : obra.getPalavrasChave()) {
                    pStat.setString(1, p.getPalavra());
                    pStat.executeUpdate();
                    salvarRelacionamentoPalavraChaveObra(con, obra, p);
                }
            }
            catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }

    private void salvarRelacionamentoPalavraChaveObra(Connection con, Obra obra, PalavraChave palavra) {
        String sql3 = "INSERT INTO obra_palavra_chave (id_obra, id_palavra_chave) " +
                "VALUES (?, ?)";
        try(PreparedStatement pStat = con.prepareStatement(sql3)) {
            pStat.setInt(1, obra.getId());
            pStat.setInt(2, palavra.getId());
            pStat.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void salvarAutores(Connection con, Obra obra) {
        String sql2 = "INSERT INTO autor (id_autor, nome) " +
                "VALUES (autor_seq.NEXTVAL, ?)";
        if(!obra.getAutores().isEmpty()) {
            try(PreparedStatement pStat = con.prepareStatement(sql2)) {
                for(Autor a : obra.getAutores()) {
                    pStat.setString(1, a.getNome());
                    pStat.executeUpdate();
                    salvarRelacionamentoAutorObra(con, obra, a);
                }
            }
            catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }
    }

    private void salvarRelacionamentoAutorObra(Connection con, Obra obra, Autor autor) {
        String sql3 = "INSERT INTO obra_autor (id_obra, id_autor) " +
                "VALUES (?, ?)";
        try(PreparedStatement pStat = con.prepareStatement(sql3)) {
            pStat.setInt(1, obra.getId());
            pStat.setInt(2, autor.getId());
            pStat.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void salvarExemplares(Connection con, Obra obra) {
        String sql4 = "INSERT INTO exemplar_obra (id_exemplar, status_exemplar, id_obra) " +
                "VALUES (1, 1, ?)";
        try(PreparedStatement pStat = con.prepareStatement(sql4)) {
            if(!obra.getExemplares().isEmpty()) {
                for(Exemplar e : obra.getExemplares()) {
                    pStat.setInt(1, obra.getId());
                }
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public List<Obra> buscarTodos() {
        String sql = "SELECT * FROM obra_literaria";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection();
            PreparedStatement pStat = con.prepareStatement(sql)) 
        {
            try(ResultSet rs = pStat.executeQuery()) {
                return construirObras(rs);
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    private List<Obra> construirObras(ResultSet rs) throws SQLException {
        List<Obra> obras = new ArrayList<>();
        while(rs.next()) {
            int id = rs.getInt("id_obra");
            String isbn = rs.getString("isbn");
            String titulo = rs.getString("titulo_obra");
            LocalDate data = rs.getDate("data_publicacao").toLocalDate();
            int edicao = rs.getInt("edicao");
            String editora = rs.getString("editora");
            int id_categoria = rs.getInt("id_categoria_obra");
            CategoriaLiteraria categoriaLiteraria = new CategoriaLiterariaDAO().buscarCategoriaPorId(id_categoria);
            List<Autor> autores = new AutorDAO().buscarAutoresPorObra(id);
            List<PalavraChave> palavrasChave = new PalavraChaveDAO().buscarPalavrasChavePorObra(id);
            List<Exemplar> exemplares = new ExemplarDAO().buscarExemplaresPorObra(id);
            Obra obra = new Obra(id, isbn, titulo, categoriaLiteraria, autores, palavrasChave, data, edicao, editora, exemplares);
            obras.add(obra);
        }
        return obras;
    }

    @Override
    public void atualizar(Obra object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remover(Obra object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Obra> buscar(int min, int max) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
