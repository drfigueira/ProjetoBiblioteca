package br.edu.ifsp.dsis4.biblioteca.dao;

import br.edu.ifsp.dsis4.biblioteca.bd.ConexaoBD;
import br.edu.ifsp.dsis4.biblioteca.entidades.Leitor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class LeitorDAO implements CrudDAO<Leitor> {

    @Override
    public void salvar(Leitor object) {
        String sql = "INSERT INTO leitor (id_leitor, email, rg_numero, rg_estado, prontuario, id_categoria_leitor, id_usuario) "
                + "VALUES (leitor_seq.NEXTVAL, ?, ?, ?, ?, ?, ?)";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection()) {
            con.setAutoCommit(false);
            try(PreparedStatement pStat = con.prepareStatement(sql)) {
                pStat.setString(1, object.getEmail());
                pStat.setString(2, object.getRg_numero());
                pStat.setString(3, object.getRg_estado());
                pStat.setString(4, object.getProntuario());
                pStat.setInt(5, object.getCategoriaLeitor().getId());
                pStat.setInt(6, object.getUsuario().getId());
                con.commit();
            }
            catch (SQLException e) {
                con.rollback();
                throw new RuntimeException(e);
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }   

    @Override
    public void atualizar(Leitor object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remover(Leitor object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Leitor> buscar(int min, int max) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Leitor> buscarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
