package br.edu.ifsp.dsis4.biblioteca.dao;

import br.edu.ifsp.dsis4.biblioteca.entidades.CategoriaLiteraria;
import br.edu.ifsp.dsis4.biblioteca.bd.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class CategoriaLiterariaDAO implements CrudDAO<CategoriaLiteraria> {

    @Override
    public void salvar(CategoriaLiteraria object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualizar(CategoriaLiteraria object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remover(CategoriaLiteraria object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CategoriaLiteraria> buscar(int min, int max) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CategoriaLiteraria> buscarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public CategoriaLiteraria buscarCategoriaPorId(int idCategoria) {
        String sql = "SELECT * FROM categoria_obra WHERE id_categoria_obra = ?";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection();
            PreparedStatement pStat = con.prepareStatement(sql)) 
        {                
            pStat.setInt(1, idCategoria);
            try(ResultSet rs = pStat.executeQuery()) {
                CategoriaLiteraria categoria = null;
                if(rs.next()) {
                    int id = rs.getInt("id_categoria_obra");
                    String descricao = rs.getString("descricao");
                    categoria = new CategoriaLiteraria(id, descricao);
                }
                return categoria;
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
