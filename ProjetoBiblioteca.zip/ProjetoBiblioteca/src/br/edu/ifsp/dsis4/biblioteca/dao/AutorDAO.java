package br.edu.ifsp.dsis4.biblioteca.dao;

import br.edu.ifsp.dsis4.biblioteca.entidades.Autor;
import br.edu.ifsp.dsis4.biblioteca.bd.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AutorDAO implements CrudDAO<Autor> {

    @Override
    public void salvar(Autor object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualizar(Autor object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remover(Autor object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Autor> buscar(int min, int max) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Autor> buscarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<Autor> buscarAutoresPorObra(int id_obra) {
        String sql = "SELECT * FROM autor WHERE id_autor IN (SELECT id_autor FROM obra_autor WHERE id_obra = ?)";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection();
            PreparedStatement pStat = con.prepareStatement(sql)) 
        {
            pStat.setInt(1, id_obra);
            try(ResultSet rs = pStat.executeQuery()) {
                List<Autor> autores = new ArrayList<>();
                while(rs.next()) {
                    int id = rs.getInt("id_autor");
                    String nome = rs.getString("nome");
                    Autor autor = new Autor(id, nome);
                    autores.add(autor);
                }
                return autores;
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
