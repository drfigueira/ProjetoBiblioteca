package br.edu.ifsp.dsis4.biblioteca.dao;

import br.edu.ifsp.dsis4.biblioteca.entidades.Exemplar;
import br.edu.ifsp.dsis4.biblioteca.bd.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;

public class ExemplarDAO implements CrudDAO<Exemplar> {

    @Override
    public void salvar(Exemplar object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void atualizar(Exemplar object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remover(Exemplar object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Exemplar> buscar(int min, int max) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Exemplar> buscarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<Exemplar> buscarExemplaresPorObra(int id_obra) {
        String sql = "SELECT * FROM exemplar_obra WHERE id_obra = ?";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection();
            PreparedStatement pStat = con.prepareStatement(sql)) 
        {
            pStat.setInt(1, id_obra);
            try(ResultSet rs = pStat.executeQuery()) {
                List<Exemplar> exemplares = new ArrayList<>();
                while(rs.next()) {
                    int id = rs.getInt("id_exemplar");
                    boolean disponivel = rs.getInt("status_exemplar") == 1;
                    Exemplar exemplar = new Exemplar(id, id_obra, disponivel);
                    exemplares.add(exemplar);
                }
                return exemplares;
            }
        }
        catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }
}
