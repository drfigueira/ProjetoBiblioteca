package br.edu.ifsp.dsis4.biblioteca.dao;

import br.edu.ifsp.dsis4.biblioteca.bd.ConexaoBD;
import br.edu.ifsp.dsis4.biblioteca.entidades.Emprestimo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class EmprestimoDAO implements CrudDAO<Emprestimo> {

    @Override
    public void salvar(Emprestimo object) {
        String sql = "INSERT INTO emprestimo_obra (id_emprestimo, data_emprestimo, data_prevista, id_leitor, id_exemplar, id_obra) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        ConexaoBD conexaoBD = ConexaoBD.getConexaoBD();
        try(Connection con = conexaoBD.getConnection();
            PreparedStatement pStat = con.prepareStatement(sql)) 
        {
            pStat.setInt(1, object.getId());
            pStat.setDate(2, java.sql.Date.valueOf(object.getDataEmprestimo()));
            pStat.setDate(3, java.sql.Date.valueOf(object.getDataPrevista()));
            pStat.setInt(4, object.getIdLeitor());
            pStat.setInt(5, object.getExemplar().getId());
            pStat.setInt(6, object.getExemplar().getIdObra());
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void atualizar(Emprestimo object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remover(Emprestimo object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Emprestimo> buscar(int min, int max) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Emprestimo> buscarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
