package br.edu.ifsp.dsis4.biblioteca.dao;

import java.util.List;

public interface CrudDAO<T> {

    public void salvar(T object);

    public void atualizar(T object);

    public void remover(T object);

    public List<T> buscar(int min, int max);

    public List<T> buscarTodos();

}
