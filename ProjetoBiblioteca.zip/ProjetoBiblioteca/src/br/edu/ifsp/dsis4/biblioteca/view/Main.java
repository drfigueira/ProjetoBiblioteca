package br.edu.ifsp.dsis4.biblioteca.view;

import br.edu.ifsp.dsis4.biblioteca.dao.ObraDAO;
import br.edu.ifsp.dsis4.biblioteca.entidades.ListaObra;

public class Main {
    public static void main(String[] args) {
        ListaObra obras = new ListaObra();
        obras.setObras(new ObraDAO().buscarTodos());
        System.out.println(obras.toString());
    }
}
