package br.edu.ifsp.dsis4.biblioteca.dao;

public class DevolucaoDAO {
}
